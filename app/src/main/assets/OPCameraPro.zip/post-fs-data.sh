TMPDIR=${0%/*}/Common
for i in `/bin/find $TMPDIR -type f -printf "%P "`; do
    /bin/mount /$TMPDIR/$i /$i
    restorecon /$i
done